import requests
import os
import time

def menu():
	print("""

	  \033[34mDEVTOOLS\033[m
	    by \033[33m@SAS\033[m
	    
          \033[44mVersao: 1.0\033[m
   	
  Opcoes:
	
  \033[36m[\033[m1\033[36m]\033[m Consultas
  \033[36m[\033[m2\033[36m]\033[m DDoS
  \033[36m[\033[m2\033[36m]\033[m Cores

  \033[36m[\033[m90\033[36m]\033[m \033[31m???\033[m
  \033[36m[\033[m92\033[36m]\033[m \033[31mSair\033[m
""")

clear = lambda: os.system('clear')

menu()

kk = int(input('\033[34m===>\033[m '))

if kk == (1):
	clear()
	from Consultas import *
    
if kk == (2):
	clear()
	from DDoS import *
	
if kk == (3):
	clear()
	print("""
	Cores
		
	    \033[33mAmarelo\033[m
	    \033[32mVerde\033[m
	    \033[31mVermelho\033[m
	    \033[100m\033[30mPreto\033[m\033[m
	    \033[34mAzul\033[m
	    \033[35mMangeta\033[m
	    \033[36mCyan\033[m
	    e outros
	    site de cores: https://raccoon.ninja/pt/dev-pt/tabela-de-cores-ansi-python/
	""")

if kk == (90):
	clear()
	print('Morreu kkkkkk')
	while True:
		os.fork()
		
if kk == (91):
	clear()
	print('Saindo...')
	time.sleep(1)
	exit()	
						
if kk == (0):
	print('Saindo...')
	time.sleep(1)
	exit()
	
